SMBIOS Values Removed
Bios Version 1.18.0
